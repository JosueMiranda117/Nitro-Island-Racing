// js/juego/pista.js

const pista = {
    // Longitud total de una vuelta, en unidades de "mundo" (no en píxeles)
    longitud: 3000,

    // Tramos de la pista: cada uno con su longitud y su curvatura
    // (curva = 0 recto, positivo = curva a la derecha, negativo = a la izquierda)
    segmentos: [
        { longitud: 450, curva: 0 },
        { longitud: 300, curva: 0.9 },
        { longitud: 450, curva: 0 },
        { longitud: 300, curva: -1.1 },
        { longitud: 450, curva: 0 },
        { longitud: 250, curva: 0.7 },
        { longitud: 400, curva: 0 },
        { longitud: 250, curva: -0.5 },
        { longitud: 150, curva: 0 }
    ],

    offsetCarretera: 0,
    curvaSuavizada: 0,
    distanciaHastaMeta: null,

    obtenerCurvaEn(distanciaMundo) {
        let d = ((distanciaMundo % this.longitud) + this.longitud) % this.longitud;
        let acumulado = 0;
        for (let seg of this.segmentos) {
            acumulado += seg.longitud;
            if (d < acumulado) return seg.curva;
        }
        return 0;
    },

    actualizar(velocidadJugador, distanciaJugador) {
        // El asfalto (líneas y pianitos) se mueve según la velocidad real del jugador,
        // así el velocímetro y la sensación de movimiento van de la mano.
        this.offsetCarretera += Math.max(velocidadJugador, 0.4) * 3;
        if (this.offsetCarretera > 1000) this.offsetCarretera -= 1000;

        // Miramos un poco "adelante" en la pista para anticipar la curva que se aproxima
        let curvaObjetivo = this.obtenerCurvaEn((distanciaJugador || 0) + 220);
        this.curvaSuavizada += (curvaObjetivo - this.curvaSuavizada) * 0.06;
    },

    // Cuánto se desplaza en X el centro de la pista para una fila dada.
    // factor = 0 -> en el horizonte (lejos) | factor = 1 -> justo frente a la cámara
    desplazamientoEnFila(factor) {
        let lejania = 1 - factor;
        return this.curvaSuavizada * lejania * lejania * 150;
    },

    dibujar(ctx, ancho, alto) {
        const centroX = ancho / 2;
        const horizonteY = alto / 2;

        // 1. Cielo con degradado
        let gradienteCielo = ctx.createLinearGradient(0, 0, 0, horizonteY);
        gradienteCielo.addColorStop(0, "#4a90e2");
        gradienteCielo.addColorStop(1, "#c8e1f8");
        ctx.fillStyle = gradienteCielo;
        ctx.fillRect(0, 0, ancho, horizonteY);

        // 2. Montañas (se corren un poco con la curva, dan sensación de giro)
        let despMontanas = this.curvaSuavizada * 20;
        ctx.fillStyle = "#5c7c59";
        ctx.beginPath();
        ctx.moveTo(-50, horizonteY);
        ctx.lineTo(-50 + despMontanas, horizonteY - 60);
        ctx.lineTo(120 + despMontanas, horizonteY - 110);
        ctx.lineTo(250 + despMontanas, horizonteY - 50);
        ctx.lineTo(400 + despMontanas, horizonteY - 130);
        ctx.lineTo(580 + despMontanas, horizonteY - 70);
        ctx.lineTo(750 + despMontanas, horizonteY - 140);
        ctx.lineTo(ancho + 50 + despMontanas, horizonteY - 40);
        ctx.lineTo(ancho + 50, horizonteY);
        ctx.closePath();
        ctx.fill();

        // 3. Terreno
        ctx.fillStyle = "#739e48";
        ctx.fillRect(0, horizonteY, ancho, alto - horizonteY);

        // 4. Carretera dibujada por franjas, para que se vea la curva
        const franjas = 24;
        const anchoHorizonte = 70;
        const anchoBase = 340;

        let puntosIzq = [];
        let puntosDer = [];

        for (let i = 0; i <= franjas; i++) {
            let factor = i / franjas;
            let y = horizonteY + (alto - horizonteY) * factor;
            let anchoFila = anchoHorizonte + (anchoBase - anchoHorizonte) * factor;
            let cx = centroX + this.desplazamientoEnFila(factor);
            puntosIzq.push({ x: cx - anchoFila, y });
            puntosDer.push({ x: cx + anchoFila, y });
        }

        ctx.fillStyle = "#3b3f46";
        ctx.beginPath();
        ctx.moveTo(puntosIzq[0].x, puntosIzq[0].y);
        for (let p of puntosIzq) ctx.lineTo(p.x, p.y);
        for (let i = puntosDer.length - 1; i >= 0; i--) ctx.lineTo(puntosDer[i].x, puntosDer[i].y);
        ctx.closePath();
        ctx.fill();

        // 5. Pianitos (cebra); su color cambia con la distancia recorrida (sensación de velocidad)
        for (let i = 0; i < franjas; i++) {
            let colorPianito = (i + Math.floor(this.offsetCarretera / 20)) % 2 === 0 ? "#e74c3c" : "#ffffff";
            ctx.fillStyle = colorPianito;

            ctx.beginPath();
            ctx.moveTo(puntosIzq[i].x, puntosIzq[i].y);
            ctx.lineTo(puntosIzq[i].x - 12, puntosIzq[i].y);
            ctx.lineTo(puntosIzq[i + 1].x - 12, puntosIzq[i + 1].y);
            ctx.lineTo(puntosIzq[i + 1].x, puntosIzq[i + 1].y);
            ctx.fill();

            ctx.beginPath();
            ctx.moveTo(puntosDer[i].x, puntosDer[i].y);
            ctx.lineTo(puntosDer[i].x + 12, puntosDer[i].y);
            ctx.lineTo(puntosDer[i + 1].x + 12, puntosDer[i + 1].y);
            ctx.lineTo(puntosDer[i + 1].x, puntosDer[i + 1].y);
            ctx.fill();
        }

        // 6. Línea central segmentada
        ctx.strokeStyle = "#f1c40f";
        ctx.lineWidth = 4;
        ctx.setLineDash([22, 22]);
        ctx.lineDashOffset = -this.offsetCarretera;
        ctx.beginPath();
        for (let i = 0; i <= franjas; i++) {
            let factor = i / franjas;
            let cx = centroX + this.desplazamientoEnFila(factor);
            let y = puntosIzq[i].y;
            if (i === 0) ctx.moveTo(cx, y); else ctx.lineTo(cx, y);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        // 7. Línea de meta, si el jugador ya la tiene cerca
        this.dibujarMeta(ctx, puntosIzq, puntosDer, franjas);
    },

    dibujarMeta(ctx, puntosIzq, puntosDer, franjas) {
        if (this.distanciaHastaMeta === null || this.distanciaHastaMeta > 260 || this.distanciaHastaMeta < 0) return;

        let factor = 1 - (this.distanciaHastaMeta / 260);
        let i = Math.max(0, Math.min(franjas - 1, Math.floor(factor * franjas)));

        let y1 = puntosIzq[i].y, y2 = puntosIzq[i + 1].y;
        let xi1 = puntosIzq[i].x, xi2 = puntosIzq[i + 1].x;
        let xd1 = puntosDer[i].x, xd2 = puntosDer[i + 1].x;

        const cuadros = 8;
        for (let c = 0; c < cuadros; c++) {
            let t1 = c / cuadros, t2 = (c + 1) / cuadros;
            ctx.fillStyle = c % 2 === 0 ? "#111111" : "#ffffff";
            ctx.beginPath();
            ctx.moveTo(xi1 + (xd1 - xi1) * t1, y1);
            ctx.lineTo(xi1 + (xd1 - xi1) * t2, y1);
            ctx.lineTo(xi2 + (xd2 - xi2) * t2, y2);
            ctx.lineTo(xi2 + (xd2 - xi2) * t1, y2);
            ctx.closePath();
            ctx.fill();
        }
    }
};
