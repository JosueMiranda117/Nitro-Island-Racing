// js/juego/rivales.js

const rivales = {
    lista: [],
    RENDER_MAX: 520,

    inicializar() {
        this.lista = [
            {
                nombre: "Muscle Rojo",
                carril: -0.7,
                distancia: 20,
                vuelta: 1,
                baseAncho: 70,
                baseAlto: 70,
                velocidadBase: 2.9,
                sprite: this.crearSprite("assets/sprites/garaje/muscle.png")
            },
            {
                nombre: "Hyperauto",
                carril: 0.7,
                distancia: 20,
                vuelta: 1,
                baseAncho: 60,
                baseAlto: 60,
                velocidadBase: 3.3,
                sprite: this.crearSprite("assets/sprites/garaje/hyperauto.png")
            },
            {
                nombre: "Muscle Morado",
                carril: -0.35,
                distancia: 40,
                vuelta: 1,
                baseAncho: 50,
                baseAlto: 50,
                velocidadBase: 3.1,
                sprite: this.crearSprite("assets/sprites/garaje/muscle.png")
            }
        ];

        this.lista.forEach(r => {
            r.velocidad = r.velocidadBase;
            r.xPantalla = 0;
            r.yPantalla = 0;
            r.anchoPantalla = 0;
            r.altoPantalla = 0;
            r.deltaDistancia = 9999;
            r.visible = false;
        });
    },

    crearSprite(ruta) {
        let img = new Image();
        img.src = ruta;
        return img;
    },

    progresoTotal(r) {
        return r.vuelta * pista.longitud + r.distancia;
    },

    actualizar() {
        if (typeof jugador === 'undefined' || typeof pista === 'undefined') return;

        const progresoJugador = jugador.vueltaActual * pista.longitud + jugador.distancia;

        // --- Avance de cada rival, con un poco de "rubber-band" para que la carrera sea pareja ---
        this.lista.forEach(r => {
            let diferencia = progresoJugador - this.progresoTotal(r);
            let ajuste = 0;
            if (diferencia > 250) ajuste = 0.6;
            else if (diferencia < -250) ajuste = -0.4;

            r.velocidad = Math.max(1.2, r.velocidadBase + ajuste);
            r.distancia += r.velocidad;

            if (r.distancia >= pista.longitud) {
                r.distancia -= pista.longitud;
                r.vuelta++;
            }
        });

        // --- Evitar que dos rivales queden totalmente encimados en el mismo carril ---
        for (let i = 0; i < this.lista.length; i++) {
            for (let j = i + 1; j < this.lista.length; j++) {
                let a = this.lista[i], b = this.lista[j];
                let cerca = Math.abs(this.progresoTotal(a) - this.progresoTotal(b)) < 22;
                let mismoCarril = Math.abs(a.carril - b.carril) < 0.35;
                if (cerca && mismoCarril) {
                    a.carril = Math.max(-1, Math.min(1, a.carril - 0.35));
                    b.carril = Math.max(-1, Math.min(1, b.carril + 0.35));
                }
            }
        }

        // --- Proyección en pantalla, según qué tan lejos está cada rival del jugador ---
        const canvas = document.getElementById("canvas-juego");
        if (!canvas) return;

        const RENDER_MAX = this.RENDER_MAX;
        const centroX = canvas.width / 2;
        const horizonteY = canvas.height / 2;
        const sueloY = canvas.height;

        this.lista.forEach(r => {
            let delta = this.progresoTotal(r) - progresoJugador;
            r.deltaDistancia = delta;

            if (delta < -20 || delta > RENDER_MAX) {
                r.visible = false;
                return;
            }
            r.visible = true;

            let factor = 1 - (delta / RENDER_MAX);
            factor = Math.max(0.05, Math.min(0.95, factor));

            let anchoCarreteraEnY = 70 + (factor * 270);
            let centro = centroX + pista.desplazamientoEnFila(factor);
            let escala = 0.35 + factor * 0.65;

            r.xPantalla = centro + r.carril * anchoCarreteraEnY * 0.5;
            r.yPantalla = horizonteY + (sueloY - horizonteY) * factor;
            r.anchoPantalla = r.baseAncho * escala;
            r.altoPantalla = r.baseAlto * escala;
        });
    },

    dibujar(ctx, subconjunto) {
        // De más lejano a más cercano, para que se tapen entre ellos correctamente.
        // Si se pasa un subconjunto (desde motor.js), se dibuja solo ese grupo.
        let base = subconjunto || this.lista.filter(r => r.visible);
        let visibles = base.slice().sort((a, b) => b.deltaDistancia - a.deltaDistancia);
        visibles.forEach(r => {
            if (r.sprite && r.sprite.complete && r.sprite.naturalWidth > 0) {
                ctx.drawImage(r.sprite, r.xPantalla - r.anchoPantalla / 2, r.yPantalla, r.anchoPantalla, r.altoPantalla);
            } else {
                ctx.fillStyle = "#e74c3c";
                ctx.fillRect(r.xPantalla - r.anchoPantalla / 2, r.yPantalla, r.anchoPantalla, r.altoPantalla);
            }
        });
    }
};