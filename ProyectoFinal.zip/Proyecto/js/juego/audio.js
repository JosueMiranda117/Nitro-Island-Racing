// js/juego/audio.js
//
// Sonido simple generado con la Web Audio API (motor, choques y cuenta regresiva).
// No depende de ningún archivo de audio externo, así que funciona de inmediato.
// TODO lo que suena aquí respeta window.volumenJuego (0 a 1), que controla
// js/app.js a partir del control deslizante de la pantalla de Configuración.
// Si más adelante agregas tus propios archivos de sonido, puedes reemplazar
// el contenido de estas funciones por elementos <audio> sin tocar el resto
// del juego (motor.js y jugador.js solo llaman a sonido.xxx()).

const sonido = {
    contexto: null,
    osciladorMotor: null,
    gananciaMotor: null,
    motorSonando: false,

    obtenerContexto() {
        const AudioContextClase = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClase) return null;

        if (!this.contexto) {
            this.contexto = new AudioContextClase();
        }
        if (this.contexto.state === "suspended") {
            this.contexto.resume();
        }
        return this.contexto;
    },

    volumenActual() {
        return typeof window.volumenJuego === 'number' ? window.volumenJuego : 0.7;
    },

    beep(frecuencia, duracion, tipo, volumenExtra) {
        const ctx = this.obtenerContexto();
        if (!ctx) return;

        const osc = ctx.createOscillator();
        const gan = ctx.createGain();
        osc.type = tipo || "sine";
        osc.frequency.value = frecuencia;

        const volumenFinal = this.volumenActual() * (volumenExtra || 1);
        gan.gain.setValueAtTime(Math.max(volumenFinal, 0.0001), ctx.currentTime);
        gan.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duracion);

        osc.connect(gan);
        gan.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duracion);
    },

    // Bip de la cuenta regresiva: "3", "2", "1" suenan distinto que el "YA" de salida
    cuentaRegresiva(valor) {
        if (valor === "YA") {
            this.beep(880, 0.25, "square", 0.5);
        } else {
            this.beep(440, 0.15, "square", 0.35);
        }
    },

    // Golpe corto al chocar con un rival
    golpe() {
        const ctx = this.obtenerContexto();
        if (!ctx) return;

        const osc = ctx.createOscillator();
        const gan = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(140, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.2);

        const volumenFinal = this.volumenActual() * 0.5;
        gan.gain.setValueAtTime(Math.max(volumenFinal, 0.0001), ctx.currentTime);
        gan.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);

        osc.connect(gan);
        gan.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
    },

    // Zumbido continuo del motor mientras corres; su tono sube con la velocidad
    iniciarMotor() {
        const ctx = this.obtenerContexto();
        if (!ctx || this.motorSonando) return;

        this.osciladorMotor = ctx.createOscillator();
        this.gananciaMotor = ctx.createGain();
        this.osciladorMotor.type = "sawtooth";
        this.osciladorMotor.frequency.value = 60;
        this.gananciaMotor.gain.value = 0;

        this.osciladorMotor.connect(this.gananciaMotor);
        this.gananciaMotor.connect(ctx.destination);
        this.osciladorMotor.start();
        this.motorSonando = true;
    },

    actualizarMotor(velocidad, velocidadMaxima) {
        if (!this.motorSonando || !this.contexto || !this.osciladorMotor) return;

        const proporcion = Math.max(0, Math.min(1, velocidad / (velocidadMaxima || 1)));
        const ahora = this.contexto.currentTime;

        this.osciladorMotor.frequency.setTargetAtTime(60 + proporcion * 160, ahora, 0.08);
        this.gananciaMotor.gain.setTargetAtTime(this.volumenActual() * 0.18, ahora, 0.08);
    },

    // Silencia el motor sin detenerlo del todo (para la pantalla de pausa)
    silenciarMotor() {
        if (!this.motorSonando || !this.contexto || !this.gananciaMotor) return;
        this.gananciaMotor.gain.setTargetAtTime(0, this.contexto.currentTime, 0.05);
    },

    detenerMotor() {
        if (!this.motorSonando) return;

        if (this.osciladorMotor) {
            try { this.osciladorMotor.stop(); } catch (e) { /* ya estaba detenido */ }
            this.osciladorMotor.disconnect();
        }
        if (this.gananciaMotor) {
            this.gananciaMotor.disconnect();
        }
        this.osciladorMotor = null;
        this.gananciaMotor = null;
        this.motorSonando = false;
    }
};