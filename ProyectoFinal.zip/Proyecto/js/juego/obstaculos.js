// js/juego/obstaculos.js

const obstaculos = {
    lista: [],
    RENDER_MAX: 520, // igual que rivales.js, para que se vean consistentes

    inicializar() {
        // 8 obstáculos distribuidos por toda la pista (longitud 3000), en carriles variados
        // para que no queden en fila. Cambia la ruta del sprite por la tuya cuando la tengas.
        const posiciones = [
            { distancia: 300, carril: -0.55 },
            { distancia: 650, carril: 0.6 },
            { distancia: 980, carril: 0.0 },
            { distancia: 1320, carril: -0.7 },
            { distancia: 1680, carril: 0.35 },
            { distancia: 2020, carril: -0.2 },
            { distancia: 2370, carril: 0.7 },
            { distancia: 2720, carril: -0.4 }
        ];

        this.lista = posiciones.map((p, i) => ({
            id: i,
            distancia: p.distancia,
            carril: p.carril,
            baseAncho: 85,
            baseAlto: 85,
            // Alterna entre dos sprites para que no se vea todo igual; ajusta las rutas a tus assets
            sprite: this.crearSprite(i % 2 === 0
                ? "assets/sprites/publico/Obstaculo.png"
                : "assets/sprites/publico/Obstaculo.png"),
            xPantalla: 0,
            yPantalla: 0,
            anchoPantalla: 0,
            altoPantalla: 0,
            deltaDistancia: 9999,
            visible: false,
            golpeado: false // evita que un mismo obstáculo te frene varias veces seguidas
        }));
    },

    crearSprite(ruta) {
        let img = new Image();
        img.src = ruta;
        return img;
    },

    actualizar() {
        if (typeof jugador === 'undefined' || typeof pista === 'undefined') return;

        const canvas = document.getElementById("canvas-juego");
        if (!canvas) return;

        const RENDER_MAX = this.RENDER_MAX;
        const centroX = canvas.width / 2;
        const horizonteY = canvas.height / 2;
        const sueloY = canvas.height;

        this.lista.forEach(o => {
            // Los obstáculos son fijos en la pista (no tienen vuelta), así que calculamos
            // la distancia más corta entre su posición y la del jugador, considerando
            // que la pista es un lazo cerrado (por eso el "envolvido" con pista.longitud).
            let delta = o.distancia - jugador.distancia;
            while (delta > pista.longitud / 2) delta -= pista.longitud;
            while (delta < -pista.longitud / 2) delta += pista.longitud;

            o.deltaDistancia = delta;

            if (delta < -20 || delta > RENDER_MAX) {
                o.visible = false;
                return;
            }
            o.visible = true;

            let factor = 1 - (delta / RENDER_MAX);
            factor = Math.max(0.05, Math.min(0.95, factor));

            let anchoCarreteraEnY = 70 + (factor * 270);
            let centro = centroX + pista.desplazamientoEnFila(factor);
            let escala = 0.55 + factor * 0.55; // piso más alto para que no se vean diminutos de lejos

            o.xPantalla = centro + o.carril * anchoCarreteraEnY * 0.5;
            o.yPantalla = horizonteY + (sueloY - horizonteY) * factor;
            o.anchoPantalla = o.baseAncho * escala;
            o.altoPantalla = o.baseAlto * escala;
        });
    },

    dibujar(ctx, subconjunto) {
        let base = subconjunto || this.lista.filter(o => o.visible);
        let visibles = base.slice().sort((a, b) => b.deltaDistancia - a.deltaDistancia);
        visibles.forEach(o => {
            if (o.sprite && o.sprite.complete && o.sprite.naturalWidth > 0) {
                ctx.drawImage(o.sprite, o.xPantalla - o.anchoPantalla / 2, o.yPantalla, o.anchoPantalla, o.altoPantalla);
            } else {
                ctx.fillStyle = "#f39c12";
                ctx.fillRect(o.xPantalla - o.anchoPantalla / 2, o.yPantalla, o.anchoPantalla, o.altoPantalla);
            }
        });
    }
};