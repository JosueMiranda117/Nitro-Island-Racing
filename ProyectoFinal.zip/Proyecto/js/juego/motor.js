// js/juego/motor.js

var canvasJuego = null;
var ctxJuego = null;
var teclasActivas = {};
var idAnimacion = null;
var tiempoInicio = Date.now();

var estadoConteo = "3";
var tiempoUltimoConteo = 0;

var pausado = false;
var clasificacionFinal = null;

function iniciarMotorJuego() {
    canvasJuego = document.getElementById("canvas-juego");
    if (!canvasJuego) {
        console.error("No se encontró el canvas-juego");
        return;
    }
    ctxJuego = canvasJuego.getContext("2d");

    tiempoInicio = Date.now();
    estadoConteo = "3";
    tiempoUltimoConteo = Date.now();
    pausado = false;
    clasificacionFinal = null;

    if (typeof jugador !== 'undefined' && typeof jugador.inicializar === 'function') {
        jugador.inicializar();
    }
    if (typeof rivales !== 'undefined' && typeof rivales.inicializar === 'function') {
        rivales.inicializar();
    }
    if (typeof obstaculos !== 'undefined' && typeof obstaculos.inicializar === 'function') {
        obstaculos.inicializar();
    }
    // Inicialización del público agregada correctamente
    if (typeof publico !== 'undefined' && typeof publico.inicializar === 'function') {
        publico.inicializar();
    }

    if (typeof pista !== 'undefined') {
        pista.offsetCarretera = 0;
        pista.curvaSuavizada = 0;
        pista.distanciaHastaMeta = pista.longitud;
    }

    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    canvasJuego.removeEventListener("click", onClickCanvasJuego);
    canvasJuego.addEventListener("click", onClickCanvasJuego);

    if (idAnimacion) cancelAnimationFrame(idAnimacion);
    bucleMotor();
}

function onKeyDown(e) {
    teclasActivas[e.key.toLowerCase()] = true;
}

function onKeyUp(e) {
    teclasActivas[e.key.toLowerCase()] = false;
}

function onClickCanvasJuego(e) {
    const rect = canvasJuego.getBoundingClientRect();
    const escalaX = canvasJuego.width / rect.width;
    const escalaY = canvasJuego.height / rect.height;
    const cx = (e.clientX - rect.left) * escalaX;
    const cy = (e.clientY - rect.top) * escalaY;
    const ancho = canvasJuego.width;

    // Botón de pausa del HUD
    const pausaX = ancho / 2 - 50, pausaY = 8, pausaW = 100, pausaH = 34;
    const dentroDePausa = cx >= pausaX && cx <= pausaX + pausaW && cy >= pausaY && cy <= pausaY + pausaH;

    if (jugador && jugador.carreraFinalizada) {
        const btnW = 220, btnH = 50;
        const btnX = ancho / 2 - btnW / 2, btnY = canvasJuego.height - 90;
        if (cx >= btnX && cx <= btnX + btnW && cy >= btnY && cy <= btnY + btnH) {
            volverAlMenuDesdeResultados();
        }
        return;
    }

    if (dentroDePausa) {
        pausado = !pausado;
        return;
    }

    if (pausado) {
        pausado = false;
    }
}

function volverAlMenuDesdeResultados() {
    if (idAnimacion) cancelAnimationFrame(idAnimacion);
    const pantallaJuego = document.getElementById("pantalla-juego");
    const menu = document.getElementById("menu-principal");
    if (pantallaJuego) pantallaJuego.classList.remove("activa");
    if (menu) menu.classList.add("activa");
}

function actualizarMotor() {
    if (estadoConteo !== "activo") {
        let ahora = Date.now();
        if (ahora - tiempoUltimoConteo >= 1000) {
            if (estadoConteo === "3") estadoConteo = "2";
            else if (estadoConteo === "2") estadoConteo = "1";
            else if (estadoConteo === "1") estadoConteo = "YA";
            else if (estadoConteo === "YA") {
                estadoConteo = "activo";
                tiempoInicio = Date.now();
            }
            tiempoUltimoConteo = ahora;
        }
        return;
    }

    if (jugador && jugador.carreraFinalizada) return;

    if (typeof jugador !== 'undefined' && typeof jugador.actualizar === 'function') {
        jugador.actualizar(teclasActivas);
    }
    if (typeof pista !== 'undefined' && typeof pista.actualizar === 'function') {
        pista.actualizar(jugador.velocidad || 0, jugador.distancia || 0);
    }
    if (typeof rivales !== 'undefined' && typeof rivales.actualizar === 'function') {
        rivales.actualizar();
    }
    if (typeof obstaculos !== 'undefined' && typeof obstaculos.actualizar === 'function') {
        obstaculos.actualizar();
    }
}

function dibujarMotor() {
    if (!ctxJuego || !canvasJuego) return;

    const ancho = canvasJuego.width;
    const alto = canvasJuego.height;

    ctxJuego.clearRect(0, 0, ancho, alto);

    if (typeof pista !== 'undefined' && typeof pista.dibujar === 'function') {
        pista.dibujar(ctxJuego, ancho, alto);
    }
    if (typeof publico !== 'undefined' && typeof publico.dibujar === 'function') {
        publico.dibujar(ctxJuego, ancho, alto);
    }

        let entidadesLejos = [];
    let entidadesCerca = [];

    if (typeof jugador !== 'undefined') {
        const deltaEquivalenteJugador = (rivales.RENDER_MAX || 520) * (1 - jugador.factorPerspectiva);

        if (typeof rivales !== 'undefined' && rivales.lista) {
            rivales.lista.forEach(r => {
                if (!r.visible) return;
                (r.deltaDistancia < deltaEquivalenteJugador ? entidadesCerca : entidadesLejos).push(r);
            });
        }
        if (typeof obstaculos !== 'undefined' && obstaculos.lista) {
            obstaculos.lista.forEach(o => {
                if (!o.visible) return;
                (o.deltaDistancia < deltaEquivalenteJugador ? entidadesCerca : entidadesLejos).push(o);
            });
        }
    }

    dibujarEntidades(ctxJuego, entidadesLejos);
    if (typeof jugador !== 'undefined' && typeof jugador.dibujar === 'function') {
        jugador.dibujar(ctxJuego);
    }
    dibujarEntidades(ctxJuego, entidadesCerca);

    // Destello rojo al chocar (contra rival u obstáculo)
    if (typeof jugador !== 'undefined' && jugador.tiempoChoque > 0) {
        let alpha = (jugador.tiempoChoque / 22) * 0.35;
        ctxJuego.fillStyle = `rgba(231, 76, 60, ${alpha})`;
        ctxJuego.fillRect(0, 0, ancho, alto);
    }

    dibujarHUDPro(ctxJuego, ancho, alto);

    const carreraTerminada = jugador && jugador.carreraFinalizada;

    if (estadoConteo !== "activo" && !carreraTerminada) {
        ctxJuego.fillStyle = "rgba(0, 0, 0, 0.6)";
        ctxJuego.fillRect(0, 0, ancho, alto);

        ctxJuego.fillStyle = estadoConteo === "YA" ? "#2ecc71" : "#e74c3c";
        ctxJuego.font = "bold 90px Arial";
        ctxJuego.textAlign = "center";
        ctxJuego.textBaseline = "middle";
        ctxJuego.fillText(estadoConteo, ancho / 2, alto / 2);
        ctxJuego.textAlign = "left";
        ctxJuego.textBaseline = "alphabetic";
    }

    if (carreraTerminada) {
        dibujarPantallaResultados(ctxJuego, ancho, alto);
    } else if (pausado) {
        dibujarPantallaPausa(ctxJuego, ancho, alto);
    }
}

function dibujarHUDPro(ctx, ancho, alto) {
    ctx.fillStyle = "rgba(10, 15, 25, 0.9)";
    ctx.fillRect(0, 0, ancho, 50);
    ctx.strokeStyle = "#e74c3c";
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, ancho, 50);

    let vActual = (jugador && jugador.vueltaActual) || 1;
    let tVueltas = (jugador && jugador.totalVueltas) || 3;
    let textoVuelta = (jugador && jugador.carreraFinalizada) ? "¡LLEGASTE!" : `Vuelta ${vActual}/${tVueltas}`;
    dibujarCajaHUD(ctx, 15, 8, 110, 34, textoVuelta);

    let segundosTranscurridos = "00.0";
    if (estadoConteo === "activo") {
        let milisegundos = Date.now() - tiempoInicio;
        segundosTranscurridos = (milisegundos / 1000).toFixed(1);
    }
    dibujarCajaHUD(ctx, 125, 8, 85, 34, `${segundosTranscurridos}s`);

    dibujarCajaHUD(ctx, ancho / 2 - 50, 8, 100, 34, pausado ? "▶ Seguir" : "⏸ Pausa");

    let posicion = calcularPosicionJugador();
    dibujarCajaHUD(ctx, ancho - 190, 8, 60, 34, posicion + "°", "#f1c40f");

    dibujarMinimapa(ctx, ancho - 115, 8, 100, 34);

    let valVelocidad = (jugador && jugador.velocidad) || 0;
    const velocidadActual = Math.abs(Math.round(valVelocidad * 25));

    ctx.fillStyle = "rgba(15, 20, 30, 0.9)";
    ctx.fillRect(ancho - 180, alto - 75, 165, 65);
    ctx.strokeStyle = "#e74c3c";
    ctx.lineWidth = 2;
    ctx.strokeRect(ancho - 180, alto - 75, 165, 65);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 13px Arial";
    ctx.fillText("VELOCÍMETRO", ancho - 165, alto - 52);

    ctx.fillStyle = "#f1c40f";
    ctx.font = "bold 18px Arial";
    ctx.fillText(velocidadActual + " KM/H", ancho - 165, alto - 25);
}
function dibujarEntidades(ctx, entidades) {
    entidades.slice().sort((a, b) => b.deltaDistancia - a.deltaDistancia).forEach(e => {
        if (e.sprite && e.sprite.complete && e.sprite.naturalWidth > 0) {
            ctx.drawImage(e.sprite, e.xPantalla - e.anchoPantalla / 2, e.yPantalla, e.anchoPantalla, e.altoPantalla);
        } else {
            ctx.fillStyle = e.hasOwnProperty("agresividad") ? "#e74c3c" : "#f39c12";
            ctx.fillRect(e.xPantalla - e.anchoPantalla / 2, e.yPantalla, e.anchoPantalla, e.altoPantalla);
        }
    });
}

function calcularPosicionJugador() {
    if (typeof jugador === 'undefined' || typeof rivales === 'undefined' || typeof pista === 'undefined') return 1;
    const progresoJugador = jugador.vueltaActual * pista.longitud + jugador.distancia;
    let posicion = 1;
    rivales.lista.forEach(r => {
        let progresoRival = r.vuelta * pista.longitud + r.distancia;
        if (progresoRival > progresoJugador) posicion++;
    });
    return posicion;
}

function obtenerClasificacionFinal() {
    let racers = [{
        nombre: "Tú",
        esJugador: true,
        progreso: jugador.vueltaActual * pista.longitud + jugador.distancia
    }];
    rivales.lista.forEach((r, idx) => {
        racers.push({
            nombre: r.nombre || `Rival ${idx + 1}`,
            esJugador: false,
            progreso: r.vuelta * pista.longitud + r.distancia
        });
    });
    racers.sort((a, b) => b.progreso - a.progreso);
    return racers;
}

function dibujarMinimapa(ctx, mapX, mapY, mapW, mapH) {
    ctx.fillStyle = "rgba(15, 25, 35, 0.9)";
    ctx.fillRect(mapX, mapY, mapW, mapH);
    ctx.strokeStyle = "#3498db";
    ctx.lineWidth = 2;
    ctx.strokeRect(mapX, mapY, mapW, mapH);

    const cx = mapX + mapW / 2;
    const cy = mapY + mapH / 2;
    const rx = mapW / 2 - 8;
    const ry = mapH / 2 - 6;

    ctx.strokeStyle = "#7f8c9b";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    ctx.stroke();

    const dibujarPunto = (progresoFraccion, color, radio) => {
        let angulo = progresoFraccion * Math.PI * 2 - Math.PI / 2;
        let px = cx + Math.cos(angulo) * rx;
        let py = cy + Math.sin(angulo) * ry;
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(px, py, radio, 0, Math.PI * 2);
        ctx.fill();
    };

    if (typeof rivales !== 'undefined' && typeof pista !== 'undefined') {
        rivales.lista.forEach(r => dibujarPunto(r.distancia / pista.longitud, "#e74c3c", 2.5));
    }
    if (typeof jugador !== 'undefined' && typeof pista !== 'undefined') {
        dibujarPunto(jugador.distancia / pista.longitud, "#2ecc71", 3.5);
    }
}

function dibujarPantallaPausa(ctx, ancho, alto) {
    ctx.fillStyle = "rgba(5, 10, 20, 0.75)";
    ctx.fillRect(0, 0, ancho, alto);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 46px Arial";
    ctx.textAlign = "center";
    ctx.fillText("PAUSA", ancho / 2, alto / 2 - 20);

    ctx.font = "16px Arial";
    ctx.fillText("Toca la pantalla para continuar", ancho / 2, alto / 2 + 20);
    ctx.textAlign = "left";
}

function dibujarPantallaResultados(ctx, ancho, alto) {
    if (!clasificacionFinal) {
        clasificacionFinal = obtenerClasificacionFinal();
    }

    ctx.fillStyle = "rgba(5, 10, 20, 0.92)";
    ctx.fillRect(0, 0, ancho, alto);

    ctx.fillStyle = "#f1c40f";
    ctx.font = "bold 38px Arial";
    ctx.textAlign = "center";
    ctx.fillText("¡CARRERA TERMINADA!", ancho / 2, 80);

    ctx.font = "bold 18px Arial";
    ctx.fillStyle = "#ffffff";
    ctx.fillText("Posiciones finales", ancho / 2, 115);

    clasificacionFinal.forEach((racer, i) => {
        let y = 160 + i * 45;
        ctx.fillStyle = racer.esJugador ? "rgba(46, 204, 113, 0.25)" : "rgba(255,255,255,0.08)";
        ctx.fillRect(ancho / 2 - 220, y - 25, 440, 38);

        ctx.fillStyle = i === 0 ? "#f1c40f" : "#ffffff";
        ctx.font = "bold 20px Arial";
        ctx.textAlign = "left";
        ctx.fillText(`${i + 1}°  ${racer.nombre}`, ancho / 2 - 200, y);

        if (racer.esJugador) {
            ctx.textAlign = "right";
            ctx.fillStyle = "#2ecc71";
            ctx.font = "bold 14px Arial";
            ctx.fillText("¡Eres tú!", ancho / 2 + 200, y);
        }
    });

    const btnW = 220, btnH = 50;
    const btnX = ancho / 2 - btnW / 2, btnY = alto - 90;
    ctx.fillStyle = "#e74c3c";
    ctx.fillRect(btnX, btnY, btnW, btnH);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 18px Arial";
    ctx.textAlign = "center";
    ctx.fillText("VOLVER AL MENÚ", ancho / 2, btnY + btnH / 2 + 6);
    ctx.textAlign = "left";
}

function dibujarCajaHUD(ctx, x, y, w, h, texto, colorBorde = "#3e5268") {
    ctx.fillStyle = "#162231";
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = colorBorde;
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 13px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(texto, x + w / 2, y + h / 2);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
}

function bucleMotor() {
    const pantallaJuegoActiva = document.getElementById("pantalla-juego");
    if (pantallaJuegoActiva && pantallaJuegoActiva.classList.contains("activa")) {
        if (!pausado) {
            actualizarMotor();
        }
        dibujarMotor();
        idAnimacion = requestAnimationFrame(bucleMotor);
    }
}