// js/juego/jugador.js

const jugador = {
    x: 500,
    y: 450,
    baseAncho: 80,
    baseAlto: 120,
    ancho: 80,
    alto: 120,

    factorPerspectiva: 0.7,
    escala: 1,

    velocidad: 0,
    maxVelocidad: 4.0,
    aceleracion: 0.07,
    friccion: 0.05,

    distancia: 0,
    vueltaActual: 1,
    totalVueltas: 3,
    carreraFinalizada: false,

    tiempoChoque: 0, // frames restantes del destello/feedback de choque

    spriteImg: null,

    inicializar() {
        if (typeof vehiculoSeleccionado !== 'undefined' && vehiculoSeleccionado && vehiculoSeleccionado.sprite) {
            this.spriteImg = new Image();
            this.spriteImg.src = vehiculoSeleccionado.sprite;
        } else {
            this.spriteImg = new Image();
            this.spriteImg.src = "assets/sprites/autos/rayo-azul.png";
        }

        const canvas = document.getElementById("canvas-juego");
        if (canvas) {
            const horizonteY = canvas.height / 2;
            const sueloY = canvas.height;

            this.escala = 0.35 + this.factorPerspectiva * 0.65;
            this.ancho = this.baseAncho * this.escala;
            this.alto = this.baseAlto * this.escala;

            this.x = canvas.width / 2;
            this.y = horizonteY + (sueloY - horizonteY) * this.factorPerspectiva;
        }

        this.velocidad = 0;
        this.distancia = 0;
        this.vueltaActual = 1;
        this.carreraFinalizada = false;
        this.tiempoChoque = 0;

        if (typeof pista !== 'undefined') {
            pista.distanciaHastaMeta = pista.longitud;
        }
    },

    actualizar(controles) {
        if (this.carreraFinalizada) return;

        if (this.tiempoChoque > 0) this.tiempoChoque--;

        const canvas = document.getElementById("canvas-juego");
        if (!canvas) return;

        // --- 1. Aceleración, freno y reversa ---
        if (controles["w"] || controles["arrowup"]) {
            this.velocidad += this.aceleracion;
            if (this.velocidad > this.maxVelocidad) this.velocidad = this.maxVelocidad;
        } else if (controles["s"] || controles["arrowdown"]) {
            this.velocidad -= this.aceleracion;
            if (this.velocidad < -2.0) this.velocidad = -2.0;
        } else {
            if (this.velocidad > 0) {
                this.velocidad -= this.friccion;
                if (this.velocidad < 0) this.velocidad = 0;
            } else if (this.velocidad < 0) {
                this.velocidad += this.friccion;
                if (this.velocidad > 0) this.velocidad = 0;
            }
        }

        // --- 2. Movimiento lateral propuesto ---
        let velocidadLateral = 4.5;
        let nuevaX = this.x;
        if (typeof pista !== 'undefined') {
            nuevaX += pista.curvaSuavizada * (this.velocidad / this.maxVelocidad) * 1.6;
        }
        if (controles["a"] || controles["arrowleft"]) nuevaX -= velocidadLateral;
        if (controles["d"] || controles["arrowright"]) nuevaX += velocidadLateral;

        // --- 3. Geometría de la carretera frente a la cámara ---
        let anchoCarreteraEnY = 70 + (this.factorPerspectiva * 270);
        let centroCarreteraEnY = (canvas.width / 2) +
            (typeof pista !== 'undefined' ? pista.desplazamientoEnFila(this.factorPerspectiva) : 0);

        let choco = false;
        let mitadJugadorCarril = (this.ancho / 2) / anchoCarreteraEnY;

        // --- 4. Choque con rivales: roce continuo + golpe fuerte en el primer contacto ---
        if (typeof rivales !== 'undefined' && rivales.lista) {
            let carrilJugador = (nuevaX - centroCarreteraEnY) / anchoCarreteraEnY;

            rivales.lista.forEach(rival => {
                if (Math.abs(rival.deltaDistancia) > 40) {
                    rival._colisionando = false;
                    return;
                }

                let mitadRivalCarril = ((rival.anchoPantalla || rival.baseAncho || 60) / 2) / anchoCarreteraEnY;
                let separacionCarril = mitadJugadorCarril + mitadRivalCarril + 0.04;

                // rivales.js dibuja con carril * anchoCarreteraEnY * 0.5, así que aquí hay que
                // usar la MISMA escala (* 0.5) para comparar contra la posición real del jugador.
                let carrilRivalEscalado = rival.carril * 0.5;
                let diferenciaCarril = carrilJugador - carrilRivalEscalado;
                if (Math.abs(diferenciaCarril) < separacionCarril) {
                    choco = true;
                    let lado = diferenciaCarril >= 0 ? 1 : -1;
                    carrilJugador = carrilRivalEscalado + lado * separacionCarril;

                    if (!rival._colisionando) {
                        this.velocidad = Math.max(0, this.velocidad - 0.9);
                        this.tiempoChoque = 14;
                    }
                    rival._colisionando = true;
                } else {
                    rival._colisionando = false;
                }
            });

            nuevaX = centroCarreteraEnY + carrilJugador * anchoCarreteraEnY;
        }

        // --- 4b. Choque con obstáculos: golpe fuerte y único hasta que te alejas de ellos ---
        if (typeof obstaculos !== 'undefined' && obstaculos.lista) {
            let carrilJugadorObs = (nuevaX - centroCarreteraEnY) / anchoCarreteraEnY;

            obstaculos.lista.forEach(o => {
    if (Math.abs(o.deltaDistancia) > 45) {
        o.golpeado = false;
        return;
    }

    let mitadObstaculoCarril = ((o.anchoPantalla || o.baseAncho || 50) / 2) / anchoCarreteraEnY;
    let separacionCarril = mitadJugadorCarril + mitadObstaculoCarril + 0.03;

    // Misma corrección de escala que con los rivales.
    let carrilObstaculoEscalado = o.carril * 0.5;
    let diferenciaCarril = carrilJugadorObs - carrilObstaculoEscalado;
    if (Math.abs(diferenciaCarril) < separacionCarril) {
        choco = true;
        let lado = diferenciaCarril >= 0 ? 1 : -1;
        carrilJugadorObs = carrilObstaculoEscalado + lado * separacionCarril;

        if (!o.golpeado) {
            this.velocidad *= 0.35;
            this.tiempoChoque = 22;
            o.golpeado = true;
        }
    }
});

            nuevaX = centroCarreteraEnY + carrilJugadorObs * anchoCarreteraEnY;
        }

        // --- 5. Límites de la carretera ---
        let limiteIzquierdo = centroCarreteraEnY - anchoCarreteraEnY + (this.ancho * 0.3);
        let limiteDerecho = centroCarreteraEnY + anchoCarreteraEnY - (this.ancho * 0.3);

        if (nuevaX < limiteIzquierdo) nuevaX = limiteIzquierdo;
        if (nuevaX > limiteDerecho) nuevaX = limiteDerecho;

        this.x = nuevaX;

        if (choco) {
            this.velocidad *= 0.9;
        }

        // --- 6. Avance real sobre la pista ---
        this.distancia += Math.max(this.velocidad, 0);

        if (this.distancia >= pista.longitud) {
            this.distancia -= pista.longitud;
            this.vueltaActual++;
            if (this.vueltaActual > this.totalVueltas) {
                this.vueltaActual = this.totalVueltas;
                this.distancia = pista.longitud;
                this.carreraFinalizada = true;
            }
        }

        if (typeof pista !== 'undefined') {
            pista.distanciaHastaMeta = this.carreraFinalizada ? 0 : (pista.longitud - this.distancia);
        }
    },

    dibujar(ctx) {
        if (this.spriteImg && this.spriteImg.complete && this.spriteImg.naturalWidth !== 0) {
            ctx.drawImage(this.spriteImg, this.x - (this.ancho / 2), this.y, this.ancho, this.alto);
        }
    }
};