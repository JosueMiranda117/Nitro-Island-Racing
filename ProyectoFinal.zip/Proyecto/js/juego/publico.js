// js/juego/publico.js

const publico = {

    imagenGrada: new Image(),
    imagenCargada: false,

    inicializar() {
        this.imagenGrada.src = "assets/sprites/publico/publico.png";
        this.imagenGrada.onload = () => {
            this.imagenCargada = true;
        };
    },

    dibujar(ctx, ancho, alto) {
        if (!this.imagenCargada) {
            return;
        }

        const centroX = ancho / 2;
        const horizonteY = alto / 2;

        const altoGrada = 35;       // Altura de las gradas
        const anchoGrada = 190;     // Ancho de cada bloque de gradas
        const anchoHorizonte = 70;  // Ancho del asfalto justo en el horizonte

        // Obtenemos el desplazamiento exacto del horizonte según la curva actual de la pista
        let desplazamientoCurva = (typeof pista !== 'undefined' && typeof pista.desplazamientoEnFila === 'function') 
            ? pista.desplazamientoEnFila(0) // factor 0 representa el horizonte
            : 0;

        let centroHorizonteX = centroX + desplazamientoCurva;

        /*
        =====================================================
        GRADA IZQUIERDA (Sigue la curva de la pista en el horizonte)
        =====================================================
        */
        ctx.drawImage(
            this.imagenGrada,
            35,     
            500,    
            1300,   
            170,    
            (centroHorizonteX - anchoHorizonte) - anchoGrada,
            horizonteY - altoGrada,
            anchoGrada,
            altoGrada
        );

        /*
        =====================================================
        GRADA DERECHA (Sigue la curva de la pista en el horizonte)
        =====================================================
        */
        ctx.drawImage(
            this.imagenGrada,
            35,
            500,
            1300,
            170,
            centroHorizonteX + anchoHorizonte,
            horizonteY - altoGrada,
            anchoGrada,
            altoGrada
        );
    }
};