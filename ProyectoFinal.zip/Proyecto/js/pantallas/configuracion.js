/* =================================
   CONFIGURACION DEL JUEGO
================================= */
//
// La lógica de guardar/aplicar resolución y volumen vive en js/app.js
// (que se carga después de este archivo), porque ahí ya están las
// referencias a los botones de Configuración. Esta función solo se
// encarga de que, cada vez que entras a la pantalla, el texto del
// volumen refleje el valor actual del control deslizante.

function inicializarConfiguracion() {
    const volumenInputActual = document.getElementById("volumen-juego");
    const valorVolumenTextoActual = document.getElementById("valor-volumen");

    if (volumenInputActual && valorVolumenTextoActual) {
        valorVolumenTextoActual.textContent = "Volumen: " + volumenInputActual.value + "%";
    }

    console.log("Configuración iniciada.");
}