// js/pantallas/tutorial.js

let canvasTutorial, ctxTutorial;
let autoTutorial = {
    x: 180,
    y: 120,
    ancho: 45,
    alto: 90,
    velocidad: 3,
    spriteImg: null
};

let teclasTutorial = {};
let desplazamientoPista = 0; // Variable para animar el movimiento automático de la carretera

function inicializarTutorial() {
    canvasTutorial = document.getElementById("canvas-tutorial");
    if (!canvasTutorial) return;
    ctxTutorial = canvasTutorial.getContext("2d");

    // Cargar la imagen del sprite del vehículo seleccionado o uno por defecto
    autoTutorial.spriteImg = new Image();
    if (typeof vehiculoSeleccionado !== 'undefined' && vehiculoSeleccionado && vehiculoSeleccionado.sprite) {
        autoTutorial.spriteImg.src = vehiculoSeleccionado.sprite;
    } else {
        autoTutorial.spriteImg.src = "assets/sprites/garaje/superauto.png";
    }

    // Escuchar eventos del teclado
    window.removeEventListener("keydown", onKeyDownTutorial);
    window.removeEventListener("keyup", onKeyUpTutorial);
    window.addEventListener("keydown", onKeyDownTutorial);
    window.addEventListener("keyup", onKeyUpTutorial);

    // Iniciar bucle de animación del tutorial
    requestAnimationFrame(bucleTutorial);
}

function onKeyDownTutorial(e) {
    teclasTutorial[e.key.toLowerCase()] = true;
}

function onKeyUpTutorial(e) {
    teclasTutorial[e.key.toLowerCase()] = false;
}

function actualizarTutorial() {
    // Movimiento libre del carro con W, S, A, D o Flechas
    if (teclasTutorial["w"] || teclasTutorial["arrowup"]) {
        autoTutorial.y -= autoTutorial.velocidad;
    }
    if (teclasTutorial["s"] || teclasTutorial["arrowdown"]) {
        autoTutorial.y += autoTutorial.velocidad;
    }
    if (teclasTutorial["a"] || teclasTutorial["arrowleft"]) {
        autoTutorial.x -= autoTutorial.velocidad;
    }
    if (teclasTutorial["d"] || teclasTutorial["arrowright"]) {
        autoTutorial.x += autoTutorial.velocidad;
    }

    // La pista se mueve sola de forma automática y constante
    desplazamientoPista += 3;

    // Limites del canvas para el carro
    if (autoTutorial.x < 10) autoTutorial.x = 10;
    if (autoTutorial.x > canvasTutorial.width - autoTutorial.ancho - 10) autoTutorial.x = canvasTutorial.width - autoTutorial.ancho - 10;
    if (autoTutorial.y < 10) autoTutorial.y = 10;
    if (autoTutorial.y > canvasTutorial.height - autoTutorial.alto - 10) autoTutorial.y = canvasTutorial.height - autoTutorial.alto - 10;
}

function dibujarTutorial() {
    if (!ctxTutorial || !canvasTutorial) return;

    const ancho = canvasTutorial.width;
    const alto = canvasTutorial.height;

    // 1. Fondo de pasto
    ctxTutorial.fillStyle = "#245c24";
    ctxTutorial.fillRect(0, 0, ancho, alto);

    // 2. Carretera
    const pistaX = ancho / 2 - 120;
    const pistaAncho = 240;

    ctxTutorial.fillStyle = "#2b2b2b";
    ctxTutorial.fillRect(pistaX, 0, pistaAncho, alto);

    // 3. Bordes laterales animados automáticamente
    const tamanoBorde = 20;
    const tamanoBloque = 40;
    let offsetBordes = desplazamientoPista % tamanoBloque;

    for (let i = -tamanoBloque + offsetBordes; i < alto; i += tamanoBloque) {
        let indiceBloque = Math.floor((i - offsetBordes) / tamanoBloque);
        
        // Lado izquierdo
        ctxTutorial.fillStyle = indiceBloque % 2 === 0 ? "#ff3333" : "#ffffff";
        ctxTutorial.fillRect(pistaX, i, tamanoBorde, tamanoBloque);

        // Lado derecho
        ctxTutorial.fillRect(pistaX + pistaAncho - tamanoBorde, i, tamanoBorde, tamanoBloque);
    }

    // 4. Línea central punteada animada automáticamente
    ctxTutorial.fillStyle = "#f1c40f";
    const anchoLinea = 8;
    const altoLinea = 30;
    const espacioLinea = 20;
    let cicloTotal = altoLinea + espacioLinea;
    let offsetLinea = desplazamientoPista % cicloTotal;

    for (let i = -cicloTotal + offsetLinea; i < alto; i += cicloTotal) {
        ctxTutorial.fillRect(ancho / 2 - anchoLinea / 2, i, anchoLinea, altoLinea);
    }

    // 5. Dibujar el carro de práctica usando el sprite cargado
    if (autoTutorial.spriteImg && autoTutorial.spriteImg.complete && autoTutorial.spriteImg.naturalWidth !== 0) {
        ctxTutorial.drawImage(
            autoTutorial.spriteImg, 
            autoTutorial.x, 
            autoTutorial.y, 
            autoTutorial.ancho, 
            autoTutorial.alto
        );
    } else {
        ctxTutorial.fillStyle = "#6d9fcf";
        ctxTutorial.fillRect(autoTutorial.x, autoTutorial.y, autoTutorial.ancho, autoTutorial.alto);
    }
}

function bucleTutorial() {
    const pantallaTuto = document.getElementById("pantalla-tutorial");
    if (pantallaTuto && pantallaTuto.classList.contains("activa")) {
        actualizarTutorial();
        dibujarTutorial();
    }
    requestAnimationFrame(bucleTutorial);
}